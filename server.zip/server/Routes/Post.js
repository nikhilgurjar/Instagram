const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const requireLogin = require('../Middleware/Requirelogin')
const Posts = mongoose.model("Post")
router.post('/createpost',requireLogin,(req,res)=>{
    const {title,body} = req.body
    if(!title || !body){
        return res.status(422).json({error:"please add all the fields"})
    }
    console.log(req.user);
    req.user.password = undefined  //to not show password
    const post = new Posts({
        title,
       body,
        postedBy:req.user
   })
    post.save()
        .then(result=>{
            res.json({post:result})
        })
        .catch(err=>console.log(err)
        )
})
router.get('/allposts',(req,res)=>{
   Posts.find()
     //this will find all posts
        .populate("postedBy","_id name")
        .then(posts=>{
            res.json(posts)
        })
        .catch(err=>console.log(err))
})
router.get('/myposts',(req,res)=>{
    Posts.find({postedBy: req.user._id})
        .populate("postedBy","_id name")
        .then(myposts=>{
            res.json({myposts})
        })
        .catch(err=>console.log(err))
})
module.exports=router;

//before adding populate method what happening was postedBy is just an id so we have to expand that see all details of it