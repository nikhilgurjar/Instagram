module.exports = {
    MONGOURI:
    "mongodb+srv://Nikhil:VvZWyvalqKZUEPVt@cluster0-7algz.mongodb.net/test?retryWrites=true&w=majority",
    JWT_SECRET:"EEFDRTO123SC"
}